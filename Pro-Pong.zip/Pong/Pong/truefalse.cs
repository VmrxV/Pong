﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pong
{
	static class truefalse
	{
		public static string l1;
		public static string l3;
	}
}
