﻿using System.Windows.Forms;

namespace Pong
{
    /// <summary>
    /// Состояние устройств ввода
    /// </summary>
    public class InputState
    {
        public Keys[] PressedKeys;
    }
}