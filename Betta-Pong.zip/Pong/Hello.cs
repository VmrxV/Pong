﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Pong
{
	public partial class Hello : Form
	{
		public Hello()
		{
			InitializeComponent();
		}

		private void helloMy1_Load(object sender, EventArgs e)
		{

		}
	}
}
