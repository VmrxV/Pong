﻿namespace Pong.Models
{
    /// <summary>
    /// Игровое поле
    /// </summary>
    public class GameRegion : GameComponent
    {
       public float Width { get; set; }
        public float Height { get; set; }
    }
}